<?php
// =============================================================================
// TEMPLATE NAME: Background image
// -----------------------------------------------------------------------------
// Background image template.
// Documentation: framework-y.com/templates/base/template-background-image.html
// =============================================================================

if (defined("HC_PLUGIN_PATH")) {
    include_once(HC_PLUGIN_PATH . "/global-content.php");
}
get_header();
signflow_the_content();
get_footer();
?>
