<?php
// =============================================================================
// INDEX.PHP
// =============================================================================

global $query;
if (is_search()) include_once(SIGNFLOW_PATH . "/inc/search.php");
else include_once(SIGNFLOW_PATH . "/template-base.php");

?>
