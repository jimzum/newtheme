'use strict';

/*
* ===========================================================
* DEFAULT SCRIPTS
* ===========================================================
* This file is loaded only if Hybrid Composer plugin is not active.
* 
* Pixor - Copyright (c) Federico Schiocchet - Pixor - Framework Y
*/


jQuery(function() {
    var projects = [{
            value: "Facebook",
            label: "Facebook",
            icon: "<?php echo get_template_directory_uri().'/img/iconfinder_1_Facebook.png' ?> "
        },
        {
            value: "Twitter",
            label: "Twitter",
            icon: "img/iconfinder_1_Twitter.png"
        },
        {
            value: "Slack",
            label: "Slack",

            icon: "img/iconfinder_1_Slack.png"
        },
        {
            value: "Youtube",
            label: "Youtube",

            icon: "img/iconfinder_1_Youtube.png"
        },
        {
            value: "Linkedin",
            label: "Linkedin",

            icon: "img/iconfinder_1_Linkedin.png"
        }
    ];
    alert(projects);

    jQuery("#project").autocomplete({
            minLength: 0,
            source: projects,
            focus: function(event, ui) {
                jQuery("#project").val(ui.item.label);
                return false;
            },
            select: function(event, ui) {
                jQuery("#project").val(ui.item.label);
                jQuery("#project-id").val(ui.item.value);
                jQuery("#project-icon").attr(ui.item.icon);

                return false;
            }
        })
        .autocomplete("instance")._renderItem = function(ul, item) {
            return jQuery("<li>")
                .append("<div>" +
                    "<img  src='" +
                    item.icon +
                    "' />" + '<span class="wish-name">' +
                    item.label +
                    "</span>" + "</div>")
                .appendTo(ul);
        };
});

(function ($) {
    var menu_open = false;
    $(document).ready(function () {
        $("body").on("click", ".navbar-toggle", function () {
            if (menu_open) {
                $(".navbar-collapse").hide();
                menu_open = false;
            } else {
                $(".navbar-collapse").show();
                menu_open = true;
            }
        });
    });
}(jQuery));

