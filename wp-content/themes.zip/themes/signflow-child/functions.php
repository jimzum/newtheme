<?php

// add shortcode for displaying search

function app_search_short_code()
{
	ob_start();
	include_once('template-app-search.php');
	return ob_get_clean();
}
add_shortcode('app-search-short-code', 'app_search_short_code');


// crease custom post type for App Search

function create_appsposttype()
{
	$labels = array(
		'name'                  => _x('Apps', 'Apps', 'textdomain'),
		'singular_name'         => _x('Apps', 'Apps', 'textdomain'),
	);
	register_post_type(
		'apps',
		array(
			'public' => true,
			'labels' => $labels,
			'capability_type' => 'appsposttype',
			'supports' => array('title', 'editor', 'thumbnail', 'custom-fields', 'excerpt'),
			'capabilities' => array(
				'publish_posts' => 'publish_apps',
				'edit_posts' => 'edit_apps',
				'edit_others_posts' => 'edit_others_apps',
				'read_private_posts' => 'read_private_apps',
				'edit_post' => 'edit_appsposttype',
				'delete_post' => 'delete_appsposttype',
				'read_post' => 'read_appsposttype',
			),
			'taxonomies' => array('category', 'post_tag'),
		)
	);
}
add_action('init', 'create_appsposttype');
function add_capability()
{
	$roles = array('administrator');

	// Loop through each role and assign capabilities
	foreach ($roles as $the_role) {
		$role = get_role($the_role);
		$role->add_cap('publish_apps');
		$role->add_cap('edit_apps');
		$role->add_cap('edit_others_apps');
		$role->add_cap('read_private_apps');
		$role->add_cap('edit_appsposttype');
		$role->add_cap('delete_appsposttype');
		$role->add_cap('read_appsposttype');
		$role->add_cap('upload_files_apps');
	}
}
add_action('admin_init', 'add_capability');

// create page with custom App Single Page template when theme is activate

if (isset($_GET['activated']) && is_admin()) {

	$new_page_title = 'App Single Page';
	$new_page_content = '';
	$new_page_template = 'template-app-single-page.php'; //ex. template-custom.php. Leave blank if you don't want a custom page template.

	//don't change the code bellow, unless you know what you're doing

	$page_check = get_page_by_title($new_page_title);
	$new_page = array(
		'post_type' => 'page',
		'post_title' => $new_page_title,
		'post_content' => $new_page_content,
		'post_status' => 'publish',
		'post_author' => 1,
	);
	if (!isset($page_check->ID)) {
		$new_page_id = wp_insert_post($new_page);
		if (!empty($new_page_template)) {
			update_post_meta($new_page_id, '_wp_page_template', $new_page_template);
		}
	}
}


add_action('admin_init', 'signflow_theme_add_editor_styles');

add_action('init', 'ajax_live_app_search');
function ajax_live_app_search()
{
	wp_enqueue_script('jquery');
	wp_register_script('ajax-script', get_stylesheet_directory_uri() . '/js/signflow-child.js');

	wp_localize_script('ajax-script', 'signflow_child_AjaxObject', array(
		'ajax_url' => admin_url('admin-ajax.php')
	));
	wp_enqueue_script('ajax-script');
	wp_register_script('jquery-ui', 'https://code.jquery.com/ui/1.12.1/jquery-ui.js', null, null, true);
	wp_enqueue_script('jquery-ui');
}
add_action('wp_ajax_nopriv_signFlowAppSearchwithAjax', 'signFlowAppSearchwithAjax');
add_action('wp_ajax_signFlowAppSearchwithAjax', 'signFlowAppSearchwithAjax');
function signFlowAppSearchwithAjax()
{
	$searchvalue = $_POST['searchValue'];
	$args = array(
		'post_type'	=> 'apps',
		'post_status' => 'publish',
		's'			=> $searchvalue,
	);
	$query = new WP_Query($args);
	$posts = $query->get_posts();
	$data = [];
	// var_dump($posts);
	// exit;
	foreach ($posts as $post) {
		$single_data = array(
			'value' => $post->ID,
			'label' => $post->post_title,
			'link' => get_permalink($post),
			'icon' => get_the_post_thumbnail_url($post->ID),
		);
		array_push($data, $single_data);
	}
	echo json_encode($data);


	wp_die();
}


add_action('wp_ajax_load_more_posts', 'load_more_posts');
add_action('wp_ajax_nopriv_load_more_posts', 'load_more_posts');
function load_more_posts()
{
	ob_clean();
	global $wpdb;
	$page_number = $_POST["pageNumber"];
	$tagslug = $_POST["tagslug"];
	$args = array(
		'post_type'  => 'apps',
		'post_status' => 'publish',
		'tag' => $tagslug,
		'posts_per_page' => 18,
		'orderby' => 'ID',
		'order' => 'DESC',
		'paged' => $page_number,
	);
	$query = new WP_Query($args);
	// echo "<pre>";
	// var_dump($query);
	$posts = $query->get_posts();
	if ($posts) {
?>
		<div class="flex-row">
			<?php
			foreach ($posts as $post) :

				// echo "<pre>";
				// print_r($post_type);
			?>
				<div class="flex-item">
					<div class="item-card">
						<div class="user-top">
							<span class="img-span"><a href="<?php echo get_permalink($post) ?>"><img class="item-card-img" width="42" height="42" src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($post->ID), 'thumbnail'); ?>"></a></span>

							<div class="item-card-body">
								<h3 class="user-title"><a href="<?php echo get_permalink($post) ?>"><?php echo $post->post_title; ?></a></h3>
								<p>
									<?php $excerpt =  get_the_excerpt($post->ID);
									if ($excerpt) {
										echo get_the_excerpt($post->ID);
									} ?>
								</p>
							</div>
						</div>
					</div>
				</div>
			<?php
			endforeach;
			?>
		</div>
		<div class="flex-row" style="justify-content: center;padding-top: 10px;">
			<?php
			if ($query->max_num_pages > $page_number) {
				echo '<div class=" load-more-btn more-post pt-5" style="justify-content: center;padding-top: 10px;"><button id="post-loader" class="btn circle-button btn-lg"> Load More </button></div>';
			}

			echo $html;
			?>
		</div>

<?php
	} else {
		echo '<h2>No data available</h2>';
		// echo $html;
	}
	wp_die();
}



function tag_filter($query)
{
	if (!is_admin() && $query->is_main_query()) {
		if ($query->is_tag) {
			$query->set('post_type', array('apps', 'post'));
		}
	}
}
add_action('pre_get_posts', 'tag_filter');
